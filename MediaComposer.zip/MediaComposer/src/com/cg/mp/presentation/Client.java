package com.cg.mp.presentation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
//import java.util.Date;
import java.sql.Date;

import com.cg.mp.dto.ArtistMasterDTO;
import com.cg.mp.exception.SongException;
import com.cg.mp.service.ISongService;
import com.cg.mp.service.SongService;

public class Client {
	public static void main(String args[]) throws SongException{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER YOUR CHOICE:\n1.Search for artist.\n2.Add new Artist.\n3.Edit an existing artist details.");
		String userChoice=sc.next();
		ArtistMasterDTO artistMaster;
		int artistId=0;
		ISongService songService=new SongService();
		switch(userChoice)
		{
		case "1":
			//Artist details for a specific artistID
			System.out.println("Enter the artist Id:");
			artistId=sc.nextInt();
			for(ArtistMasterDTO ArtistMasterDTO:songService.searchArtist(artistId))
			{
				System.out.println(ArtistMasterDTO);
			}
			break;
		case "2":
		{
			System.out.println("Enter the Artist Name:");
			String artistName=sc.next();
			System.out.println("ENter the Artist Type:");
			String artistType=sc.next();
			System.out.println("Enter the Artist's Birth Date:");
			String artistDateOfBirth=sc.next();
			System.out.println("Enter the Artist's Death date:");
			String artistDeathDate=sc.next();
			System.out.println("Enter the Creator:");
			int artistCreator=sc.nextInt();
			System.out.println("Creation Date:");
			String artistCreationDate=sc.next();
			System.out.println("Updated by:");
			int artistUpdator=sc.nextInt();
			System.out.println("Updated on:");
			String artistUpdationDate=sc.next();
			System.out.println("Deletion Status:");
			int artistDeletion=sc.nextInt();
			DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate dateDeath=LocalDate.parse(artistDeathDate,formatter);
			Date artdateDeath=Date.valueOf(dateDeath);
			DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate dateBirth=LocalDate.parse(artistDateOfBirth,formatter1);
			Date artdateBirth=Date.valueOf(dateBirth);
			
			DateTimeFormatter formatter2=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate dateOfCreation=LocalDate.parse(artistCreationDate,formatter2);
			Date artdateOfCreation=Date.valueOf(dateOfCreation);
			
			DateTimeFormatter formatter3=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate dateOfUpdation=LocalDate.parse(artistCreationDate,formatter3);
			Date artdateOfUpdation=Date.valueOf(dateOfUpdation);
			
			try{
				artistId=songService.getArtistId();
			}catch(SongException se)
			{
				throw new SongException("Problem in fetching ArtistId");
			}
			artistMaster=new ArtistMasterDTO(artistId,artistName,artistType,artdateBirth,artdateDeath,artistCreator,artdateOfCreation,
					artistUpdator,artdateOfUpdation,artistDeletion);
			int status=0;
			status=songService.addNewArtist(artistMaster);	
			if(status!=0)
			{
				System.out.println("Artist Successfully Added!!");
			}
			else
				System.out.println("Problem in the addition of new Artist");
			break;
		}
		case "3":
		{
			
		}
		}
		
	}
}
