package com.cg.mp.presentation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
//import java.util.Date;
import java.sql.Date;

import com.cg.mp.dto.ArtistMasterDTO;
import com.cg.mp.dto.ComposerMasterDTO;
import com.cg.mp.exception.SongException;
import com.cg.mp.service.ISongService;
import com.cg.mp.service.SongService;

public class Client {
	public static void main(String args[]) throws SongException{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER YOUR CHOICE:\n1.Search for artist.\n2.Add new Artist.\n3.Edit an existing artist details.\n4.Delete an artist details.\n5.Show all artists.\n6.Search by name.\n7.Search artist by gender.");
		String userChoice=sc.next();
		ArtistMasterDTO artistMaster;
		ArtistMasterDTO artistMasterDTO = new ArtistMasterDTO();
		int artistId=0;
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
		ISongService songService=new SongService();
		switch(userChoice)
		{
		case "1":
			//Artist details for a specific artistID
			System.out.println("Enter the artist Id:");
			artistId=sc.nextInt();
			List<ArtistMasterDTO> artistMasterList=songService.searchArtist(artistId);
			if(artistMasterList.isEmpty())
			{
				System.out.println("No artist found for the artist id:"+artistId);
				break;
			}
			else
			{
				for(ArtistMasterDTO ArtistMasterDTO:songService.searchArtist(artistId))
				{
					System.out.println(ArtistMasterDTO);
				}
				break;
			}
			
		case "2":
			System.out.println("Enter Artist Name:");
			String artistName=sc.next();
			System.out.println("ENter the Artist Type:M for Male and F for Female");
			String artistType=sc.next();
			if(artistType.equals("M")|| artistType.equals("F"))
			{
				System.out.println("Enter Artist Born date:");
				String artistBorn=sc.next();
				LocalDate artistBornDateLocal=LocalDate.parse(artistBorn,formatter);
				Date artistBornDate=Date.valueOf(artistBornDateLocal);
				System.out.println("Is the Artist dead?(y/n)");
				String choice4=sc.next();
				if(choice4.equals("Y") || choice4.equals("y"))
				{
					System.out.println("Enter Artist Died date:yyyy-mm-dd format");
					String composerDied=sc.next();
					LocalDate diedDateLocal=LocalDate.parse(composerDied,formatter);
					Date artistDiedDate=Date.valueOf(diedDateLocal);
					
					artistMasterDTO.setArtistDiedDate(artistDiedDate);
				}
				else
					artistMasterDTO.setArtistDiedDate(null);
					
				System.out.println("Enter the Creator:");
				int artistCreator=sc.nextInt();
				System.out.println("Updated by:");
				int artistUpdator=sc.nextInt();
				
				System.out.println("Deletion Status:");
				int artistDeletion=sc.nextInt();
				artistMasterDTO.setArtistName(artistName);
				artistMasterDTO.setArtistBornDate(artistBornDate);
				artistMasterDTO.setArtistType(artistType);
				artistMasterDTO.setCreatedBy(artistCreator);
				artistMasterDTO.setUpdatedBy(artistUpdator);
				artistMasterDTO.setArtistDelFlag(artistDeletion);
				int status=0;
				try {
					
					status=songService.addNewArtist(artistMasterDTO);
				} catch (SongException e) {
					System.out.println(e.getMessage());
				}
				
				if(status!=0)
				{
					System.out.println("Artist Successfully Added!!");
				}
				else
					System.out.println("Problem in the addition of new Artist");
				break;
			}
			else
				System.out.println("Enter a valid Artist Type");
		
		case "3":
		{
			System.out.println("Enter the artist Id you want to edit the details for: ");
			artistId=sc.nextInt();
			System.out.println("What do u want to edit?");
			System.out.println("*************************");
			System.out.println("1.Death Date");
			System.out.println("Enter choice: ");
			int choiceArtist=sc.nextInt();
			ArtistMasterDTO artistMasterDTOEdit=new ArtistMasterDTO();
			switch(choiceArtist)
			{
			case 1:
				System.out.println("Enter the death date in yyyy-mm-dd format: ");
				String deathDate=sc.next();
				formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate deathDateLocal=LocalDate.parse(deathDate,formatter);
				Date deathDateDate=Date.valueOf(deathDateLocal);
				artistMasterDTOEdit.setArtistDiedDate(deathDateDate);
				artistMasterDTOEdit.setArtistId(artistId);
				try {
					songService.editArtistDetails(artistMasterDTOEdit,choiceArtist);
					System.out.println("Artist details succesfully edited");
				} catch (SongException e) {
					System.out.println(e.getMessage());
				}
				
				break;
			}
			break;
		}	
		case "4":
		{
			System.out.println("Enter the artist's id you want to delete");
			artistId=sc.nextInt();
			int status=songService.deleteArtistDetails(artistId);
			if(status==0)
			{
				System.out.println("No deletion has been performed");
				break;
			}
			else
				System.out.println("Deletion done for artistId:"+artistId);
			break;
		}
		case "5":
		{
			System.out.println("The list of artists:");
			List<ArtistMasterDTO> artistList=new ArrayList();
			try
			{
				artistList=songService.retrieveAllArtists();
			}
			catch(SongException se)
			{
				System.out.println(se.getMessage()+"No artist Found");
			}
		for(ArtistMasterDTO artists: artistList)
		{
			System.out.println(artists.toString());
		}
		}
		case "6":
		{
			System.out.println("Enter the name of the artist you want to search:");
			String searchArtistName=sc.next();
			List<ArtistMasterDTO> stat=songService.searchArtistByName(searchArtistName);
			if(stat.isEmpty())
			{
				System.out.println("Sorry!No artist has been found with name"+searchArtistName+" !!");
				break;
			}
			else
				for(ArtistMasterDTO ArtistMasterDTO:songService.searchArtistByName(searchArtistName))
				{
					System.out.println(ArtistMasterDTO);
				}
			break;
		}
		case "7":
		{
			System.out.println("Enter the type of artist you want to search:");
			System.out.println("Press M for Male or Press F for Female");
			artistType=sc.next();
			List<ArtistMasterDTO> statusForType=songService.searchArtistByType(artistType);
			if(statusForType.isEmpty())
			{
				System.out.println("Sorry!No artist has been found with this artistType"+artistType+" !!");
				break;
			}
			else
				for(ArtistMasterDTO ArtistMasterDTO:songService.searchArtistByType(artistType))
				{
					System.out.println(ArtistMasterDTO);
				}
			break;
		}
		}
		}
		
	}

