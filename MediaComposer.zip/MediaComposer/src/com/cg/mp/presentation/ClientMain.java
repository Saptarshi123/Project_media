package com.cg.mp.presentation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
//import java.util.Date;
import java.sql.Date;

import com.cg.mp.dto.ArtistMasterDTO;
import com.cg.mp.dto.ComposerMasterDTO;
import com.cg.mp.exception.SongException;
import com.cg.mp.service.ISongService;
import com.cg.mp.service.SongService;

public class ClientMain {
	public static void main(String args[]) throws SongException{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER YOUR CHOICE:\n1.Search for artist.\n2.Add new Artist.\n3.Edit an existing artist details.\n4.Delete an artist details.\n5.Show all artists.\n6.Search by name.\n7.Search artist by gender.");
		String userChoice=sc.next();
		ArtistMasterDTO artistMaster;
		int artistId=0;
		int composerId=0;
		DateTimeFormatter formatter=null;
		ISongService songService=new SongService();
		switch(userChoice)
		{
		case "1":
			//Artist details for a specific artistID
			System.out.println("Enter the artist Id:");
			artistId=sc.nextInt();
			for(ArtistMasterDTO ArtistMasterDTO:songService.searchArtist(artistId))
			{
				System.out.println(ArtistMasterDTO);
			}
			break;
		case "2":
		{
			System.out.println("Enter the Artist Name:");
			String artistName=sc.next();
			System.out.println("ENter the Artist Type:");
			String artistType=sc.next();
			System.out.println("Enter the Artist's Birth Date:");
			String artistDateOfBirth=sc.next();
			System.out.println("Enter the Artist's Death date:");
			String artistDeathDate=sc.next();
			System.out.println("Enter the Creator:");
			int artistCreator=sc.nextInt();
			System.out.println("Creation Date:");
			String artistCreationDate=sc.next();
			System.out.println("Updated by:");
			int artistUpdator=sc.nextInt();
			System.out.println("Updated on:");
			String artistUpdationDate=sc.next();
			System.out.println("Deletion Status:");
			int artistDeletion=sc.nextInt();
			formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate dateDeath=LocalDate.parse(artistDeathDate,formatter);
			Date artdateDeath=Date.valueOf(dateDeath);
			DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate dateBirth=LocalDate.parse(artistDateOfBirth,formatter1);
			Date artdateBirth=Date.valueOf(dateBirth);
			
			DateTimeFormatter formatter2=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate dateOfCreation=LocalDate.parse(artistCreationDate,formatter2);
			Date artdateOfCreation=Date.valueOf(dateOfCreation);
			
			DateTimeFormatter formatter3=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate dateOfUpdation=LocalDate.parse(artistCreationDate,formatter3);
			Date artdateOfUpdation=Date.valueOf(dateOfUpdation);
			
			try{
				artistId=songService.getArtistId();
			}catch(SongException se)
			{
				throw new SongException(se.getMessage()+"Problem in fetching ArtistId");
			}
			artistMaster=new ArtistMasterDTO(artistId,artistName,artistType,artdateBirth,artdateDeath,artistCreator,artdateOfCreation,
					artistUpdator,artdateOfUpdation,artistDeletion);
			int status=0;
			status=songService.addNewArtist(artistMaster);	
			if(status!=0)
			{
				System.out.println("Artist Successfully Added!!");
			}
			else
				System.out.println("Problem in the addition of new Artist");
			break;
		}
		case "3":
		{
			System.out.println("Enter the artist Id you want to edit: ");
			artistId=sc.nextInt();
			System.out.println("What do u want to edit?");
			System.out.println("*************************");
			System.out.println("1.Death Date");
			System.out.println("Enter choice: ");
			int choiceArtist=sc.nextInt();
			ArtistMasterDTO artistMasterDTOEdit=new ArtistMasterDTO();
			switch(choiceArtist)
			{
			case 1:
				System.out.println("Enter the death date in yyyy-mm-dd format: ");
				String deathDate=sc.next();
				formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate deathDateLocal=LocalDate.parse(deathDate,formatter);
				Date deathDateDate=Date.valueOf(deathDateLocal);
				artistMasterDTOEdit.setArtistDiedDate(deathDateDate);
				artistMasterDTOEdit.setArtistId(artistId);
				try {
					songService.editArtistDetails(artistMasterDTOEdit,choiceArtist);
					System.out.println("Artist details succesfully edited");
				} catch (SongException e) {
					System.out.println(e.getMessage());
				}
				
				break;
			}
			break;
		}	
		case "4":
		{
			System.out.println("Enter the artist's id you want to delete");
			artistId=sc.nextInt();
			int status=songService.deleteArtistDetails(artistId);
			if(status==0)
			{
				System.out.println("No deletion has been performed");
				break;
			}
			else
				System.out.println("Deletion done for artistId:"+artistId);
			break;
		}
		case "5":
		{
			System.out.println("The list of artists:");
			List<ArtistMasterDTO> artistList=new ArrayList();
			try
			{
				artistList=songService.retrieveAllArtists();
			}
			catch(SongException se)
			{
				System.out.println(se.getMessage()+"No artist Found");
			}
		for(ArtistMasterDTO artists: artistList)
		{
			System.out.println(artists.toString());
		}
		}
		case "6":
		{
			System.out.println("Enter the name of the artist you want to search:");
			String artistName=sc.next();
			List<ArtistMasterDTO> status=songService.searchArtistByName(artistName);
			if(status.isEmpty())
			{
				System.out.println("Sorry!No artist has been found with name"+artistName+" !!");
				break;
			}
			else
				for(ArtistMasterDTO ArtistMasterDTO:songService.searchArtistByName(artistName))
				{
					System.out.println(ArtistMasterDTO);
				}
			break;
		}
		case "7":
		{
			System.out.println("Enter the type of artist you want to search:");
			System.out.println("Press M for Male or Press F for Female");
			String artistType=sc.next();
			List<ArtistMasterDTO> status=songService.searchArtistByType(artistType);
			if(status.isEmpty())
			{
				System.out.println("Sorry!No artist has been found with this artistType"+artistType+" !!");
				break;
			}
			else
				for(ArtistMasterDTO ArtistMasterDTO:songService.searchArtistByType(artistType))
				{
					System.out.println(ArtistMasterDTO);
				}
			break;
		}
		}
		}
		
	}

