package com.cg.mp.presentation;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.mp.dto.ArtistMasterDTO;
import com.cg.mp.dto.ComposerMasterDTO;
import com.cg.mp.exception.SongException;
import com.cg.mp.service.ISongService;
import com.cg.mp.service.SongService;

public class ClientDup {
	
public static void main(String args[])
{
	ArtistMasterDTO artistMasterDTO=new ArtistMasterDTO();
	ISongService songService=new SongService();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your choice:");
	System.out.println("Enter choice:");
	int choice3=sc.nextInt();
	switch(choice3)
	{
	case 1:
	System.out.println("Enter Artist Name:");
	String artistName=sc.next();
	System.out.println("ENter the Artist Type:");
	String artistType=sc.next();
	System.out.println("Enter Artist Born date:");
	String artistBorn=sc.next();
	DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
	LocalDate artistBornDateLocal=LocalDate.parse(artistBorn,formatter);
	Date artistBornDate=Date.valueOf(artistBornDateLocal);
	System.out.println("Is the Artist dead?(y/n)");
	String choice4=sc.next();
	Date artistDiedDate=null;
	if(choice4.equals("Y") || choice4.equals("y"))
	{
	System.out.println("Enter Artist Died date:");
	String composerDied=sc.next();
	LocalDate diedDateLocal=LocalDate.parse(composerDied,formatter);
    artistDiedDate=Date.valueOf(diedDateLocal);
	artistMasterDTO.setArtistDiedDate(artistDiedDate);
	}
	else
		artistMasterDTO.setArtistDiedDate(null);
	System.out.println("Enter the Creator:");
	int artistCreator=sc.nextInt();
	System.out.println("Creation Date:");
	String artistCreationDate=sc.next();
	DateTimeFormatter formatter2=DateTimeFormatter.ofPattern("yyyy-MM-dd");
	LocalDate dateOfCreation=LocalDate.parse(artistCreationDate,formatter2);
	Date artdateOfCreation=Date.valueOf(dateOfCreation);
	
	System.out.println("Updated by:");
	int artistUpdator=sc.nextInt();
	
	System.out.println("Updated on:");
	String artistUpdationDate=sc.next();

	DateTimeFormatter formatter3=DateTimeFormatter.ofPattern("yyyy-MM-dd");
	LocalDate dateOfUpdation=LocalDate.parse(artistCreationDate,formatter3);
	Date artdateOfUpdation=Date.valueOf(dateOfUpdation);
	System.out.println("Deletion Status:");
	int artistDeletion=sc.nextInt();
	artistMasterDTO.setArtistName(artistName);
	artistMasterDTO.setArtistBornDate(artistBornDate);
	artistMasterDTO.setArtistType(artistType);
	artistMasterDTO.setArtistDiedDate(artistDiedDate);
	
	artistMasterDTO.setCreatedBy(artistCreator);
	artistMasterDTO.setCreatedOn(artdateOfCreation);
	artistMasterDTO.setUpdatedBy(artistUpdator);
	artistMasterDTO.setUpdatedOn(artdateOfUpdation);
	artistMasterDTO.setArtistDelFlag(artistDeletion);
	try {
		songService.addNewArtist(artistMasterDTO);
	} catch (SongException e) {
		System.out.println(e.getMessage());
	}
	break;
	}
	
}

}
