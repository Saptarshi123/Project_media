package com.cg.mp.service;

import java.util.List;

import com.cg.mp.dto.ArtistMasterDTO;
import com.cg.mp.exception.SongException;

public interface ISongService {
	List<ArtistMasterDTO> searchArtist(int artistId) throws SongException;

	int getArtistId() throws SongException;

	int addNewArtist(ArtistMasterDTO artistMaster)  throws SongException; 
}
