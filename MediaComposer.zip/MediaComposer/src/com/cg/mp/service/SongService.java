package com.cg.mp.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.mp.dao.ArtistDAO;
import com.cg.mp.dao.IArtistDAO;
import com.cg.mp.dto.ArtistMasterDTO;
import com.cg.mp.dto.SongMasterDTO;
import com.cg.mp.exception.SongException;

public class SongService implements ISongService{

	IArtistDAO songService=new ArtistDAO();
	@Override
	public List<ArtistMasterDTO> searchArtist(int artistId)
			throws SongException {
		List<ArtistMasterDTO> artistList=songService.searchArtist(artistId);
		return artistList;
	}
	@Override
	public int getArtistId() throws SongException {
		int artistId=songService.getArtistId();
		return artistId;
	}
	@Override
	public int addNewArtist(ArtistMasterDTO artistMaster) throws SongException {
		int status=0;
		status=songService.addNewArtist(artistMaster);
		return status;
	}
	@Override
	public void editArtistDetails(ArtistMasterDTO artistMasterDTOEdit,
			int choiceArtist) throws SongException {
		songService.editArtistDetails(artistMasterDTOEdit,choiceArtist);
		
	}
	@Override
	public int deleteArtistDetails(int artistId) throws SongException {
		int status=0;
		status=songService.deleteArtistDetails(artistId);
		return status;
		
	}
	@Override
	public List<ArtistMasterDTO> retrieveAllArtists() throws SongException {
		List<ArtistMasterDTO> artistList=songService. retrieveAllArtists();
		return artistList;
	}
	@Override
	public List<ArtistMasterDTO> searchArtistByName(String artistName)
			throws SongException {
		List<ArtistMasterDTO> artistList=new ArrayList();
		artistList=songService.searchArtistByName(artistName);
				return artistList;
		
	}
	@Override
	public List<ArtistMasterDTO> searchArtistByType(String artistType)
			throws SongException {
		
		List<ArtistMasterDTO> artistList=new ArrayList();
		artistList=songService.searchArtistByType(artistType);
				return artistList;
	}
	@Override
	public List<SongMasterDTO> getSongsByName(String searchartistName)
			throws SongException {
		
		return songService.getSongsByName(searchartistName);
	}
	
	
	
	}

