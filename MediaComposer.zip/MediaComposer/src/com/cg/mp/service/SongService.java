package com.cg.mp.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.cg.mp.utility.*;
import com.cg.mp.dao.ArtistDAO;
import com.cg.mp.dao.IArtistDAO;
import com.cg.mp.dto.ArtistMasterDTO;
import com.cg.mp.exception.SongException;

public class SongService implements ISongService{

	IArtistDAO songService=new ArtistDAO();
	@Override
	public List<ArtistMasterDTO> searchArtist(int artistId)
			throws SongException {
		List<ArtistMasterDTO> artistList=songService.searchArtist(artistId);
		return artistList;
	}
	@Override
	public int getArtistId() throws SongException {
		int artistId=songService.getArtistId();
		return artistId;
	}
	@Override
	public int addNewArtist(ArtistMasterDTO artistMaster) throws SongException {
		int status=0;
		status=songService.addNewArtist(artistMaster);
		return status;
	}
	@Override
	public void editArtistDetails(ArtistMasterDTO artistMasterDTOEdit,
			int choiceArtist) throws SongException {
		songService.editArtistDetails(artistMasterDTOEdit,choiceArtist);
		
	}
	@Override
	public int deleteArtistDetails(int artistId) throws SongException {
		int status=0;
		status=songService.deleteArtistDetails(artistId);
		return status;
		
	}
	@Override
	public List<ArtistMasterDTO> retrieveAllArtists() throws SongException {
		List<ArtistMasterDTO> artistList=songService. retrieveAllArtists();
		return artistList;
	}
	@Override
	public int searchArtistByName(String artistName)
			throws SongException {
		int status=0;
		status=songService.searchArtistByName(artistName);
				return status;
		
	}
	
	
	
	}

