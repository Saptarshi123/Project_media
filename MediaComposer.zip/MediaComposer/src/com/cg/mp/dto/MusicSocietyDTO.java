package com.cg.mp.dto;

public class MusicSocietyDTO {

	private String composerMusicSocId;
	private String composerMusicSocName;
	public String getComposerMusicSocId() {
		return composerMusicSocId;
	}
	public void setComposerMusicSocId(String composerMusicSocId) {
		this.composerMusicSocId = composerMusicSocId;
	}
	public String getComposerMusicSocName() {
		return composerMusicSocName;
	}
	public void setComposerMusicSocName(String composerMusicSocName) {
		this.composerMusicSocName = composerMusicSocName;
	}
	
}
