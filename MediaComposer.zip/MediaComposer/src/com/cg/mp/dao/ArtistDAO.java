package com.cg.mp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mp.dto.ArtistMasterDTO;
import com.cg.mp.exception.SongException;
import com.cg.mp.utility.DBUtil;

public class ArtistDAO implements IArtistDAO{


	@Override
	public List<ArtistMasterDTO> searchArtist(int artistId) throws SongException {
		List<ArtistMasterDTO> artistList=new ArrayList<ArtistMasterDTO>();
		Connection conn=null;
		PreparedStatement pstmt=null;
		int count=0;
		String sql=new String("SELECT * FROM Artist_Master where Artist_Id="+artistId);
		try
		{
		conn=DBUtil.createConnection();
		Statement stmt = conn.createStatement();
		ResultSet rset = stmt.executeQuery (sql);
		while(rset.next())
		{
			ArtistMasterDTO artistMasterDTO=new ArtistMasterDTO();
			artistMasterDTO.setArtistId(rset.getInt(1));
			artistMasterDTO.setArtistName(rset.getString(2));
			artistMasterDTO.setArtistType(rset.getString(3));
			artistMasterDTO.setArtistBornDate(rset.getDate(4));
			artistMasterDTO.setArtistDiedDate(rset.getDate(5));
			artistMasterDTO.setCreatedBy(rset.getInt(6));
			artistMasterDTO.setCreatedOn(rset.getDate(7));
			artistMasterDTO.setUpdatedBy(rset.getInt(8));
			artistMasterDTO.setUpdatedOn(rset.getDate(9));
			artistMasterDTO.setArtistDelFlag(rset.getInt(10));
			artistList.add(artistMasterDTO);
			
		
		}
		}catch(SQLException se)
		{
			throw new SongException(se.getMessage()+"Please enter correct credentials.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new SongException("Problems in closing connection.",se);
			}
		}	
		return artistList;
	}

	@Override
	public int getArtistId() throws SongException
	{
		
		Connection conn=null;
		PreparedStatement pstStudent=null;
		int artistId;
		
		String sql=new String("SELECT Artist_Master_Seq.nextval FROM Dual");
		try
		{
		conn=DBUtil.createConnection();
		Statement stmt = conn.createStatement();
		ResultSet rset = stmt.executeQuery (sql);
		rset.next();
		artistId=rset.getInt(1);
		
		}catch(SQLException se)
		{
			throw new SongException("Problem in generating artistId.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new SongException("Problems in closing connection.",se);
			}
		}
		
		
		return artistId;
	}

	@Override
	public int addNewArtist(ArtistMasterDTO artistMaster) throws SongException {
		int status=0;
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		
		String sql=new String("INSERT INTO Artist_Master VALUES(?,?,?,?,?,?,?,?,?,?)");
		try
		{
		connStudent=DBUtil.createConnection();
		
		pstStudent=connStudent.prepareStatement(sql);
		
		
		pstStudent.setInt(1,artistMaster.getArtistId());
		pstStudent.setString(2,artistMaster.getArtistName());
		pstStudent.setString(3,artistMaster.getArtistType());
		pstStudent.setDate(4,artistMaster.getArtistBornDate());
		pstStudent.setDate(5,artistMaster.getArtistDiedDate());	
		pstStudent.setInt(6,artistMaster.getCreatedBy());
		pstStudent.setDate(7,artistMaster.getCreatedOn());
		pstStudent.setInt(8,artistMaster.getUpdatedBy());
		pstStudent.setDate(9,artistMaster.getUpdatedOn());
		pstStudent.setInt(10,artistMaster.getArtistDelFlag());
		status=pstStudent.executeUpdate();
		}catch(SQLException se)
		{
			throw new SongException("Problem in adding artist details.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new SongException("Problems in closing connection.",se);
			}
		}
		return status;
	}

	@Override
	public void editArtistDetails(ArtistMasterDTO artistMasterDTOEdit,
			int choiceArtist) throws SongException {
		switch(choiceArtist)
		{
		case 1:
			Connection connection=null;
			Statement stmt=null;
			Statement stmt1=null;
			String date=new String("SELECT to_char(to_date('"+artistMasterDTOEdit.getArtistDiedDate()+"','yyyy-mm-dd'),'dd-mon-yyyy') FROM DUAL");
			
			try
			{
			connection=DBUtil.createConnection();
			stmt = connection.createStatement();
			stmt1 = connection.createStatement();
			ResultSet rset = stmt.executeQuery (date);
			rset.next();
			
			date=rset.getString(1);
			String sql=new String("UPDATE artist_master SET artist_dieddate='"+date
			+"' WHERE artist_id="+artistMasterDTOEdit.getArtistId());
			int check=stmt1.executeUpdate(sql);
			
			}catch(SQLException se)
			{
				throw new SongException(se.getMessage()+" and Problem in updation.");
			}finally
			{
				try
				{
					DBUtil.closeConnection();
				}catch(SQLException se)
				{
					throw new SongException("Problems in closing connection.",se);
				}
			}
			break;
		}
	}

	@Override
	public int deleteArtistDetails(int artistId) throws SongException {
		int status=0;
		Connection conn=null;
		PreparedStatement pst=null;
		try 
	     {  
			
			conn=DBUtil.createConnection();
	        pst = conn.prepareStatement("DELETE FROM artist_master WHERE artist_id="+artistId);
	        status=pst.executeUpdate(); 
	     }
	     catch(Exception se)
	     {
	         System.out.println(se.getMessage()+"No deletion done" );
	     }
		return status;
	}
}
